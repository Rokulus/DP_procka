import os
import json

from fastapi import APIRouter, Depends, HTTPException, Request, Query
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from typing import Union, List

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api import deps
from app.core.security import get_password_hash
from app.models import User
from app.schemas.requests import UserCreateRequest, UserUpdatePasswordRequest
from app.schemas.responses import UserResponse

from pathlib import Path

router = APIRouter()

templates = Jinja2Templates(directory="static/templates")

@router.get("/model-info")
async def show_model_info(
    request: Request,
):
    path = "static/assets/models_xml"
    files = os.listdir(path)
    return templates.TemplateResponse("info.html", {
        "request": request,
        "files": json.dumps(files)
    })

@router.get("/model/{modelName}")
def show_model(
    request: Request,
    modelName: str,
    modelMode: Union[str, None] = "continuous",
    stopTime: float = 10,
    dataSets: List[str] = Query([]),
    stepSize: float = 0.1,
    interval: float = 30
):
    # if(os.path.isdir(f"/var/www/fastapi/assets/models/{modelName}") == False):
    #     return {"Model does not exist"}
    f = open(f'static/assets/models/{modelName}/{modelName}.js', 'r')
    content = f.read()
    f.close()
    return templates.TemplateResponse("model.html", {
        "request": request,
        "modelName": modelName,
        "modelMode": modelMode,
        "stopTime": stopTime,
        "dataSets": json.dumps(dataSets),
        "stepSize": stepSize,
        "interval": interval,
        "contentOfJS": content
    })
